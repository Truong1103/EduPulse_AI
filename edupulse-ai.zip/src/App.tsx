import React, { useState, useEffect } from 'react';
import { AppRoute } from './types';

// Common Components
import { Navbar } from './components/common/Navbar';
import { Footer } from './components/common/Footer';
import { ScrollToTop } from './components/common/ScrollToTop';
import { Toast, ToastMessage } from './components/common/Toast';

// Landing Page Sections with Real Photography & Real Content
import { HeroSection } from './components/landing/HeroSection';
import { WhatIsEduPulse } from './components/landing/WhatIsEduPulse';
import { MultiGoalDomains } from './components/landing/MultiGoalDomains';
import { StudentJourneysSection } from './components/landing/StudentJourneysSection';
import { AIEarlyDetection } from './components/landing/AIEarlyDetection';
import { TimelySupportScenarios } from './components/landing/TimelySupportScenarios';
import { HowItWorksSteps } from './components/landing/HowItWorksSteps';
import { PrivacySafetySection } from './components/landing/PrivacySafetySection';
import { CallToAction } from './components/landing/CallToAction';

// Public & Auth Pages (Ready for Backend Integration)
import { FeaturesPage } from './components/pages/FeaturesPage';
import { HowItWorksPage } from './components/pages/HowItWorksPage';
import { AboutPage } from './components/pages/AboutPage';
import { LoginPage } from './components/pages/LoginPage';
import { RegisterOnboardingPage } from './components/pages/RegisterOnboardingPage';

export default function App() {
  const [currentRoute, setCurrentRoute] = useState<AppRoute>('landing');
  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  // Synchronize route with URL hash for easy browser navigation
  useEffect(() => {
    const handleHashChange = () => {
      const hash = window.location.hash.replace('#', '') as AppRoute;
      const validRoutes: AppRoute[] = [
        'landing',
        'features',
        'how-it-works',
        'about',
        'login',
        'register'
      ];
      if (validRoutes.includes(hash)) {
        setCurrentRoute(hash);
      }
    };

    if (window.location.hash) {
      handleHashChange();
    }

    window.addEventListener('hashchange', handleHashChange);
    return () => window.removeEventListener('hashchange', handleHashChange);
  }, []);

  const addToast = (title: string, message: string, type: 'success' | 'info' | 'warning' = 'success') => {
    const newToast: ToastMessage = {
      id: `toast-${Date.now()}-${Math.random()}`,
      title,
      message,
      type
    };
    setToasts((prev) => [...prev, newToast]);

    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== newToast.id));
    }, 4500);
  };

  const handleDismissToast = (id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  };

  const navigateTo = (route: AppRoute) => {
    setCurrentRoute(route);
    window.location.hash = route === 'landing' ? '' : route;
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleLoginSubmit = () => {
    addToast(
      'Giao diện sẵn sàng kết nối!',
      'Giao diện đăng nhập đã sẵn sàng để tích hợp API Backend và Google OAuth sau này.',
      'info'
    );
  };

  const handleRegisterSubmit = () => {
    addToast(
      'Giao diện sẵn sàng kết nối!',
      'Dữ liệu đăng ký và mục tiêu học sinh đã sẵn sàng để gửi đến máy chủ Backend.',
      'info'
    );
  };

  const scrollToSection = (id: string) => {
    if (currentRoute !== 'landing') {
      navigateTo('landing');
      setTimeout(() => {
        const el = document.getElementById(id);
        if (el) el.scrollIntoView({ behavior: 'smooth' });
      }, 100);
    } else {
      const el = document.getElementById(id);
      if (el) el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 text-slate-900 font-sans selection:bg-sky-500 selection:text-white">
      {/* Toast Notification Container */}
      <Toast toasts={toasts} onDismiss={handleDismissToast} />

      {/* Floating Scroll-to-Top Button */}
      <ScrollToTop />

      {/* Header / Navbar */}
      <Navbar
        currentRoute={currentRoute}
        onRouteChange={navigateTo}
      />

      {/* Main Content Router */}
      <main className="flex-1">
        {currentRoute === 'landing' && (
          <div>
            <HeroSection
              onNavigate={navigateTo}
              onExploreClick={() => scrollToSection('about-intro')}
            />
            <WhatIsEduPulse onNavigate={navigateTo} />
            <MultiGoalDomains />
            <StudentJourneysSection />
            <AIEarlyDetection />
            <TimelySupportScenarios
              onActionTriggered={(t, m) => addToast(t, m)}
            />
            <HowItWorksSteps />
            <PrivacySafetySection />
            <CallToAction onNavigate={navigateTo} />
          </div>
        )}

        {currentRoute === 'features' && <FeaturesPage onNavigate={navigateTo} />}

        {currentRoute === 'how-it-works' && <HowItWorksPage onNavigate={navigateTo} />}

        {currentRoute === 'about' && <AboutPage onNavigate={navigateTo} />}

        {currentRoute === 'login' && (
          <LoginPage
            onNavigate={navigateTo}
            onLoginSuccess={handleLoginSubmit}
          />
        )}

        {currentRoute === 'register' && (
          <RegisterOnboardingPage
            onNavigate={navigateTo}
            onCompleteOnboarding={handleRegisterSubmit}
          />
        )}
      </main>

      {/* Footer */}
      <Footer onRouteChange={navigateTo} />
    </div>
  );
}
