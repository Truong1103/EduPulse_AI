export type GoalCategory = 'academic' | 'language' | 'sports' | 'arts' | 'skills';

export interface StudentStory {
  id: string;
  name: string;
  school: string;
  avatar: string;
  category: GoalCategory;
  categoryLabel: string;
  goalTitle: string;
  duration: string;
  consistencyResult: string;
  quote: string;
}

export type AppRoute =
  | 'landing'
  | 'features'
  | 'how-it-works'
  | 'about'
  | 'login'
  | 'register';
